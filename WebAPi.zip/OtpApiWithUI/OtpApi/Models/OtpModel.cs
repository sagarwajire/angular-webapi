﻿using System.ComponentModel.DataAnnotations;

namespace OtpApi.Models
{
    public class OtpRequest
    {
        public string UserId { get; set; }
        public DateTime DateTime { get; set; }
    }

    // Models/OtpResponse.cs
    public class OtpResponse
    {
        public string Otp { get; set; }
        public int TimeRemaining { get; set; }
    }
    public class OtpValidationRequest
    {
        [Required]
        public string UserId { get; set; }

        [Required]
        public string Otp { get; set; }
    }
}
