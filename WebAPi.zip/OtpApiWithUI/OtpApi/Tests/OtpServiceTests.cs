﻿
using Microsoft.Extensions.Caching.Memory;
using Moq;
using OtpApi.Repository;
using OtpApi.Services;
using Xunit;

namespace OtpApi.Tests
{
    public class OtpServiceTests
    {
        private readonly Mock<IOtpRepository> _mockRepository;
        private readonly IMemoryCache _memoryCache;
        private readonly OtpService _otpService;

        public OtpServiceTests()
        {
            _mockRepository = new Mock<IOtpRepository>();
            _memoryCache = new MemoryCache(new MemoryCacheOptions());
            _otpService = new OtpService(_mockRepository.Object, _memoryCache);
        }

        [Fact]
        public void GenerateOtp_ShouldReturnValidOtpResponse()
        {
            var response = _otpService.GenerateOtp("user123");
            Assert.NotNull(response.Otp);
            Assert.Equal(30, response.TimeRemaining);
        }

        [Fact]
        public void ValidateOtp_ShouldReturnTrue_IfOtpIsValid()
        {
            var otp = "123456";
            _mockRepository.Setup(repo => repo.GetOtp("user123")).Returns((otp, DateTime.UtcNow.AddSeconds(30)));

            var result = _otpService.ValidateOtp("user123", otp);

            Assert.True(result);
        }


    }
}
