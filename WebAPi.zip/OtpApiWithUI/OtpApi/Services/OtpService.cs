﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Caching.Memory;
using OtpApi.Models;
using OtpApi.Repository;
using System;

namespace OtpApi.Services
{


    public class OtpService : IOtpService
    {
        private readonly IOtpRepository _otpRepository; // Repository to handle OTP storage and retrieval
        private readonly IMemoryCache _cache; // In-memory cache for storing OTPs temporarily
        private readonly int _otpValidityDuration = 30; // Duration in seconds for OTP validity


        public OtpService(IOtpRepository otpRepository, IMemoryCache cache)
        {
            _otpRepository = otpRepository; // Inject the OTP repository
            _cache = cache;  // Inject the memory cache
        }

        public OtpResponse GenerateOtp(string userId)
        {
            var otp = new Random().Next(100000, 999999).ToString(); // Generate a 6-digit OTP
            var expiry = DateTime.UtcNow.AddSeconds(_otpValidityDuration); // Set expiry time for OTP

            // Save OTP in repository
            _otpRepository.SaveOtp(userId, otp, expiry);

            // Save OTP in cache for faster access
            _cache.Set(userId, otp, expiry);

            return new OtpResponse
            {
                Otp = otp,
                TimeRemaining = _otpValidityDuration
            };
        }

        public bool ValidateOtp(string userId, string otp)
        {
            // Check cache first
            if (_cache.TryGetValue(userId, out string cachedOtp) && cachedOtp == otp)
            {
                return true; // Return true if OTP matches the cached value
            }

            // If not in cache, check repository
            var storedOtp = _otpRepository.GetOtp(userId);
            if (storedOtp.HasValue && storedOtp.Value.Otp == otp && DateTime.UtcNow <= storedOtp.Value.Expiry)
            {
                return true; // Return true if OTP matches the stored value and is not expired
            }

            return false; // Return false if OTP is invalid or expired
        }
    }
}