﻿using Microsoft.AspNetCore.Http;
using OtpApi.Models;

namespace OtpApi.Services
{
    public interface IOtpService
    {
        // Method to generate an OTP for a given user
        OtpResponse GenerateOtp(string userId);
        // Method to Validate an OTP for a given user
        bool ValidateOtp(string userId, string otp);
    }
}
