﻿namespace OtpApi.Repository
{
    public class OtpRepository : IOtpRepository
    {
        // Dictionary to store OTPs in memory, with the user ID as the key
        // Each entry contains a tuple of the OTP string and its expiry time
        private readonly Dictionary<string, (string Otp, DateTime Expiry)> _otpStore = new();

        // Method to save the OTP and its expiry for a given user ID
        public void SaveOtp(string userId, string otp, DateTime expiry)
        {
            _otpStore[userId] = (otp, expiry); // Store or update the OTP data in the dictionary
        }

        // Method to retrieve the OTP and its expiry for a given user ID
        public (string Otp, DateTime Expiry)? GetOtp(string userId)
        {
            // Try to get the OTP data from the dictionary
            _otpStore.TryGetValue(userId, out var otpData);
            return otpData; // Return the OTP data if found, or null if not found
        }
    }
}

