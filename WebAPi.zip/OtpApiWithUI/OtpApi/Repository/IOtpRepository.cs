﻿namespace OtpApi.Repository
{
    public interface IOtpRepository
    {
        // Method to save an OTP 
        void SaveOtp(string userId, string otp, DateTime expiry);
        // Method to get an OTP 
        (string Otp, DateTime Expiry)? GetOtp(string userId);
    }
}
