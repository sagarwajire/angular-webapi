﻿using Microsoft.AspNetCore.Mvc;
using OtpApi.Models;
using OtpApi.Services;

namespace OtpApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class OtpController : ControllerBase
    {
        private readonly IOtpService _otpService;// Dependency injection for the OTP service
        // Constructor for the OtpController, accepting an IOtpService instance
        public OtpController(IOtpService otpService)
        {
            _otpService = otpService;// Initialize the OTP service
        }
        // API endpoint to generate an OTP
        [HttpPost("generate")]
        public IActionResult GenerateOtp([FromBody] OtpRequest request)
        {
            // Calls the OTP service to generate an OTP for the specified UserId
            var response = _otpService.GenerateOtp(request.UserId);
            return Ok(response); // Returns the generated OTP in an OK response
        }
        // API endpoint to validate an OTP
        [HttpPost("validate")]
        public IActionResult ValidateOtp([FromBody] OtpValidationRequest request)
        {
            // Check if the request model is valid
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState); // Return a 400 Bad Request if model validation fails
            }
            // Calls the OTP service to validate the OTP for the specified UserId
            bool isValid = _otpService.ValidateOtp(request.UserId, request.Otp);

            if (isValid)
            {
                return Ok(new { message = "OTP is valid" }); // Returns the validate OTP in an OK response
            }
            else
            {
                return Ok(new { message = "Invalid OTP or expired" }); // Returns the validate OTP is expire

            }
        }
    }
}