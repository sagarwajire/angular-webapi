export const environment = {
    production: false,
    apiUrl: 'https://localhost:44354/api' // URL of your API
  };