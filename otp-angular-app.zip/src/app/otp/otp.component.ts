import { Component } from '@angular/core';
import { OtpService } from '../otp.service';
import { FormsModule } from '@angular/forms';
import { CommonEngine } from '@angular/ssr';
import { CommonModule } from '@angular/common';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { BrowserModule } from '@angular/platform-browser';


@Component({
  selector: 'app-otp',
  standalone: true,
  imports: [FormsModule,CommonModule],
  templateUrl: './otp.component.html',
  styleUrl: './otp.component.css'
})
export class OtpComponent {
  otp: string = ''; // OTP input by the user
  remainingTime: string = ''; // Remaining time until OTP expiration
  userId: string = 'user1'; // Example user ID
  generatedOtp: string = ''; // OTP generated for the user
  requestTime: Date = new Date(); // Time when OTP was requested
  otpIsValid: boolean | null = null; 
  constructor(private otpService: OtpService) { }

  /**
   * Calls the OTP service to generate a new OTP and starts the countdown.
   */
  generateOtp() {
    this.otpService.generateOtp(this.userId, this.requestTime).subscribe(response => {
      this.generatedOtp = response.otp;
      this.remainingTime = this.formatTime(response.timeRemaining);
      this.startCountdown();
    });
  }

  /**
   * Validates the entered OTP.
   */
  validateOtp() {
    this.otpService.validateOtp(this.userId, this.generatedOtp).subscribe(response => {
      console.log(response);
      this.otpIsValid = response.message; // Store validity status
    });
  }

  /**
   * Starts the countdown for OTP validity.
   */
  private startCountdown() {
    setInterval(() => {
      if (this.remainingTime !== '0:00') {
        const [minutes, seconds] = this.remainingTime.split(':').map(Number);
        let totalSeconds = minutes * 60 + seconds - 1;
        if (totalSeconds >= 0) {
          this.remainingTime = `${Math.floor(totalSeconds / 60)}:${totalSeconds % 60 < 10 ? '0' : ''}${totalSeconds % 60}`;
        } else {
          this.remainingTime = '0:00';
        }
      }
    }, 1000);
  }

  /**
   * Formats the time span into minutes and seconds.
   * @param timeSpan The time span to format.
   * @returns The formatted time string.
   */
  formatTime(seconds: number): string {
    if (isNaN(seconds) || seconds < 0) {
      return '0:00';
    }
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds < 10 ? '0' : ''}${remainingSeconds}`;
  }
}