import { Routes } from '@angular/router';
import { OtpComponent } from './otp/otp.component';

export const routes: Routes = [
    { path: 'otp', component: OtpComponent },
    { path: '', redirectTo: '/otp', pathMatch: 'full' },  // Default route
    { path: '**', redirectTo: '/otp' }  // Wildcard route for 404
  ];
