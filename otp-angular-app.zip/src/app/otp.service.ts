import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from './environment';

const API_URL = `${environment.apiUrl}/otp`;
@Injectable({
  providedIn: 'root'
})
export class OtpService {
  constructor(private http: HttpClient) { }

  /**
   * Calls the API to generate an OTP.
   * @param userId The ID of the user requesting the OTP.
   * @param requestTime The time of the OTP request.
   * @returns An Observable of the OTP response containing the OTP and remaining time.
   */
  generateOtp(userId: string, requestTime: Date): Observable<any> {
    return this.http.post<any>(`${API_URL}/generate`, { userId, requestTime });
  }

  /**
   * Calls the API to validate an OTP.
   * @param userId The ID of the user whose OTP is being validated.
   * @param otp The OTP to validate.
   * @returns An Observable indicating whether the OTP is valid or not.
   */
  validateOtp(userId: string, otp: string): Observable<any> {
    const body = { userId: userId, otp: otp };
    return this.http.post(`${API_URL}/validate`, body);
  }
}
